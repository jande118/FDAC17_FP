#!/bin/bash

# check usage
if [ $# -le 1 ]; then
	echo "USAGE: ./subpackage.sh [data file] [first package name] [second package name] ..."
	exit
fi

# initialize data input file variable
INPUT="$1"
if [ ! -r "$INPUT" ]; then # check data file exists
	echo "Data file does not exist or is not readable."
	exit
fi

# create new file for better indexing purposes
echo "Creating index file."
#./index_packages.sh $1 ## !!! This is a really long command so unnecessary if .index file exists
INDEXFILE="$1.index"

# create reindex file from index file using python script
echo "Re indexing index file."
#./reindex.py $INDEXFILE
REINDEXFILE="$INDEXFILE.reindex"

# loop arguments of package manager names
shift
for PKG in "$@"; do
	# assume first line of input was a header
	sed "1q;d" $INPUT > ./$PKG.data # output files
	NUMSED=$(grep --count "$PKG" $REINDEXFILE)
	echo " Creating extract file for the $PKG Package manager (using $NUMSED sed commands):"
	let i=0
	grep "$PKG" $REINDEXFILE | while read -r line; do
		let i=$i+1
		echo "Writing next cluster of rows to output file ($i/$NUMSED)..."
		#echo "$line"
		K=$(echo "$line" | cut -d',' -f 2)
		STARTAT="$(expr $K - 1)"
		STOPAT=$(echo "$line" | cut -d',' -f 3)
		sed -e "1,${STARTAT}d;${STOPAT}q" $INPUT >>./$PKG.data
	done
	echo "Finished writing output file!"
done

